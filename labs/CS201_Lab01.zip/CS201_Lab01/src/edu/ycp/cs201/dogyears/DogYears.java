package edu.ycp.cs201.dogyears;

import java.util.Scanner;

public class DogYears {
	public static void main(String[] args) {
		// TODO: add your code here
	}
}
