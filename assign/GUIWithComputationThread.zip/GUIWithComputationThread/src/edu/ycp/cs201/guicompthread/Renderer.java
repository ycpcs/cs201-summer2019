package edu.ycp.cs201.guicompthread;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

// The renderer takes a Model and produces a BufferedImage.
public class Renderer {
	private Model model;
	private BufferedImage img;
	
	public Renderer(Model model) {
		this.model = model;
		this.img = new BufferedImage(Model.WIDTH, Model.HEIGHT, BufferedImage.TYPE_INT_RGB);
	}
	
	public BufferedImage getImg() {
		return img;
	}
	
	public void render() {
		int[][] data = model.getData();
		
		Graphics g = img.getGraphics();
		
		for (int i = 0; i < Model.HEIGHT; i++) {
			for (int j = 0; j < Model.WIDTH; j++) {
				g.setColor(new Color(data[i][j]));
				g.fillRect(j, i, 1, 1);
			}
		}
		
		g.dispose();
	}
}
