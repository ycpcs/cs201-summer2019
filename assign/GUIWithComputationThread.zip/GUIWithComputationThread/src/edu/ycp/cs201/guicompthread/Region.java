package edu.ycp.cs201.guicompthread;

public class Region implements Cloneable {
	private int startX, startY;
	private int endX, endY;
	
	public Region() {
		
	}
	
	public void setStart(int x, int y) {
		x = clampX(x);
		y = clampY(y);
		
		startX = x;
		startY = y;
		// set the end x/y as well
		endX = x;
		endY = y;
	}
	
	public void setEnd(int x, int y) {
		x = clampX(x);
		y = clampY(y);
		endX = x;
		endY = y;
	}
	
	public int getMinX() {
		return Math.min(startX, endX);
	}
	
	public int getMinY() {
		return Math.min(startY, endY);
	}
	
	public int getWidth() {
		return Math.max(startX, endX) - getMinX();
	}
	
	public int getHeight() {
		return Math.max(startY, endY) - getMinY();
	}
	
	public void reset() {
		startX = endX = startY = endY = 0;
	}
	
	@Override
	public Region clone() {
		try {
			return (Region) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException("Cannot happen");
		}
	}
	
	private static int clampX(int x) {
		if (x < 0) { return x; }
		if (x >= Model.WIDTH) { return Model.WIDTH - 1; }
		return x;
	}
	
	private static int clampY(int y) {
		if (y < 0) { return y; }
		if (y >= Model.HEIGHT) { return Model.HEIGHT - 1; }
		return y;
	}
}
