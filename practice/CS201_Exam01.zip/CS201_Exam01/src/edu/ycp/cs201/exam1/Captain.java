package edu.ycp.cs201.exam1;

/**
 * An instance of the Captain class represents
 * a Star Fleet captain
 */
public class Captain {
	// TODO: add fields.
	// You need to store information about the Captain (use the following variable names and types:
	//     firstName (String), lastName (String), gradYear (int), shipName (String)



	// TODO: add constructor that accepts first name and last name
	//       initialize gradYear to 0, and shipName to null



	// TODO: add constructor that accepts first name, last name, grad year, and ship name


	
	// TODO: add getter methods for each field in the Captain class
	//       the method names must MATCH those called in the JUNit test cases



	// TODO: add setter methods for shipName and gradYear
	//       the method names MUST match those called in the JUnit test cases


	
	// TODO: add a method that returns the Captain's full name in the form
	//                     "firstName lastName"
	//       the method name MUST match that called in the JUnit test case

}
