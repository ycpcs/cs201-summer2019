package edu.ycp.cs201.exam1;

public class Target {
	// TODO: declare the fields


	// TODO: create the Target constructor that accepts an array of Points (arrow locations)
	//          and sets arrows to the array passed in.
	//       the constructor must also calculate the score for the set of arrow locations

	
	// getter method that returns the score
	// NOTE: it does not calculate the score, that must be done in the constructor
	public double getScore() {
		return this.score;
	}
	
	// getter method that returns a reference to the arrows array
	public Point[] getArrows() {
		return this.arrows;
	}
	
	// TODO: define a calcScore method that calculates the score for all arrows
	//       calcScore must be called from the Target constructor to set the score
	//       the score is the average distance of all arrows from the center of the target (0,0)
	//       the arrows hit the target at the Point coordinates stored in the arrows array

	
	
}
