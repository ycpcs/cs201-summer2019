package edu.ycp.cs201.exam02;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class Q11TestHidden {
	@Rule
	public Timeout globalTimeout = Timeout.millis(2000); // 2 seconds

	@Test
	public void testFieldsAreDeclared() throws Exception {
		Map<Class<?>, Integer> required = new HashMap<>();
		required.put(PokemonType.class, 2);
		required.put(String.class, 1);
		assertTrue(Util.verifyFields(Pokemon.class, required));
	}
	
	@Test
	public void testFieldsArePrivate() throws Exception {
		assertTrue(Util.allFieldsArePrivate(Pokemon.class));
	}
}
