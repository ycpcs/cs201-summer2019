package edu.ycp.cs201.exam02;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class Q12TestHidden {
	@Rule
	public Timeout globalTimeout = Timeout.millis(2000); // 2 seconds
	
	@Test
	public void testNotSortedIntListPairsOrdered() throws Exception {
		List<Integer> lst = Arrays.asList(5, 13, 1, 17, 8, 16, 7, 19, 3, 12);
		assertFalse(Q12.isSorted(lst));
	}
	
	@Test
	public void testNotSortedIntListFirstIsSmallest() throws Exception {
		List<Integer> lst = Arrays.asList(1, 5, 13, 17, 16, 8, 7, 19, 12, 3);
		assertFalse(Q12.isSorted(lst));
	}
}
