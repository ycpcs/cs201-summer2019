package edu.ycp.cs201.exam1;

import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class TargetTestHidden {
	private static final double DELTA = 0.000001;
	
	private Target t1, t2, t3;
	private Point[] arr1;
	private Point[] arr2;
	private Point[] arr3;
	private double arr1Score;
	private double arr2Score;
	private double arr3Score;
	
	@Before
	public void setUp() {
		this.arr1 = new Point[]{
				new Point(1.08, 1.09),
				new Point(0.70, 1.08),
				new Point(0.01, 0.59),
				new Point(1.22, 0.20),
				new Point(0.97, 1.43),
				new Point(0.26, 0.90),
				new Point(0.35, 0.93),
				new Point(1.19, 0.13),
				new Point(0.39, 0.18),
				new Point(0.57, 0.44),
		};
		this.arr1Score = 1.065293326268466;
		this.arr2 = new Point[]{
				new Point(0.12, 1.30),
				new Point(1.30, 0.79),
				new Point(0.26, 1.03),
				new Point(0.39, 1.09),
				new Point(0.22, 1.06),
				new Point(1.13, 1.07),
				new Point(1.12, 0.78),
				new Point(1.27, 1.28),
				new Point(0.85, 0.45),
				new Point(0.60, 0.34),
				new Point(0.67, 0.30),
				new Point(0.60, 1.28),
				new Point(0.59, 0.32),
				new Point(0.68, 0.80),
				new Point(0.84, 0.66),
				new Point(1.17, 0.10),
				new Point(1.03, 0.38),
				new Point(1.48, 1.13),
				new Point(0.32, 0.43),
				new Point(0.71, 0.49),
				new Point(0.27, 0.87),
				new Point(0.08, 1.12),
				new Point(1.39, 0.83),
				new Point(0.68, 1.17),
				new Point(0.77, 0.53),
				new Point(1.00, 1.39),
				new Point(0.41, 0.92),
				new Point(1.23, 0.74),
				new Point(0.75, 1.14),
				new Point(0.07, 0.80),
		};
		this.arr2Score = 1.174611958700357;
		this.arr3 = new Point[]{
				new Point(0.81, 1.34),
		};
		this.arr3Score = 1.5657905351610735;
		
		t1 = new Target(arr1);
		t2 = new Target(arr2);
		t3 = new Target(arr3);
	}
	
	@Test
	public void testGetArrows1() throws Exception {
		assertSame(arr1, t1.getArrows());
	}
	
	@Test
	public void testGetArrows2() throws Exception {
		assertSame(arr2, t2.getArrows());
	}
	
	@Test
	public void testGetArrows3() throws Exception {
		assertSame(arr3, t3.getArrows());
	}
	
	@Test
	public void testGetScore1() throws Exception {
		assertEquals(arr1Score, t1.getScore(), DELTA);
	}
	
	@Test
	public void testGetScore2() throws Exception {
		assertEquals(arr2Score, t2.getScore(), DELTA);
	}
	
	@Test
	public void testGetScore3() throws Exception {
		assertEquals(arr3Score, t3.getScore(), DELTA);
	}
	
	@Test
	public void testFieldsAreDeclared() throws Exception {
		Map<Class<?>, Integer> required = new HashMap<>();
		required.put(Point[].class, 1);
		required.put(Double.TYPE, 1);
		assertTrue(Util.verifyFields(Target.class, required));
	}
	
	@Test
	public void testFieldsArePrivate() throws Exception {
		assertTrue(Util.allFieldsArePrivate(Target.class));
	}
}
