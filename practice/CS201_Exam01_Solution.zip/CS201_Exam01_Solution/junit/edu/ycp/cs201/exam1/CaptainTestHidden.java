package edu.ycp.cs201.exam1;

import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;

public class CaptainTestHidden {
	private Captain c1;
	private Captain c2;
	
	@Before
	public void setUp() {
		c1 = new Captain("Thursday", "Next");
		c2 = new Captain("Landen", "Park-Laine", 2011, "Whale Shark");
	}
	
	// testGetFirstName
	@Test
	public void testGetFirstName() throws Exception {
		assertEquals("Thursday", c1.getFirstName());
		assertEquals("Landen", c2.getFirstName());
	}
	
	// testGetLastName
	@Test
	public void testGetLastName() throws Exception {
		assertEquals("Next", c1.getLastName());
		assertEquals("Park-Laine", c2.getLastName());
	}
	
	// testGetGradYear
	@Test
	public void testGetGradYear() throws Exception {
		assertEquals(2011, c2.getGradYear());
	}
	
	// testGetShipName
	@Test
	public void testGetShipName() throws Exception {
		assertEquals("Whale Shark", c2.getShipName());
	}
	
	@Test
	public void testGetGradYearReturnsZero() throws Exception {
		assertEquals(0, c1.getGradYear());
	}
	
	@Test
	public void testGetShipNameReturnsNull() throws Exception {
		assertNull(c1.getShipName());
	}
	
	private static final Pattern pat1 = Pattern.compile("^\\s*Thursday\\s*Next\\s*$");
	private static final Pattern pat2 = Pattern.compile("^\\s*Landen\\s*Park-Laine\\s*$");
	
	// testGetFullNameIgnoreSpacing
	@Test
	public void testGetFullNameIgnoreSpacing() throws Exception {
		Matcher m1 = pat1.matcher(c1.getFullName().toString());
		assertTrue(m1.find());
		Matcher m2 = pat2.matcher(c2.getFullName().toString());
		assertTrue(m2.find());
	}
	
	// testGetFullName
	@Test
	public void testGetFullNameExact() throws Exception {
		assertEquals("Thursday Next", c1.getFullName().toString());
		assertEquals("Landen Park-Laine", c2.getFullName().toString());
	}
	
	// testSetGradYear
	@Test
	public void testSetGradYear() throws Exception {
		c1.setGradYear(2016);
		assertEquals(2016, c1.getGradYear());
		c2.setGradYear(2024);
		assertEquals(2024, c2.getGradYear());
	}
	
	// testSetShipName
	@Test
	public void testSetShipName() throws Exception {
		c1.setShipName("Millennium Falcon");
		assertEquals("Millennium Falcon", c1.getShipName());
		c2.setShipName("HMS Bounty");
		assertEquals("HMS Bounty", c2.getShipName());
	}
	
	// testShipNamesAreIndependent
	@Test
	public void testShipNamesAreIndependent() throws Exception {
		c1.setShipName("Foobar");
		assertEquals("Whale Shark", c2.getShipName());
		assertEquals("Foobar", c1.getShipName());
		c2.setShipName("Splunge");
		assertEquals("Foobar", c1.getShipName());
		assertEquals("Splunge", c2.getShipName());
	}
	
	// testGradYearsAreIndependent
	@Test
	public void testGradYearsAreIndependent() throws Exception {
		c1.setGradYear(1066);
		assertEquals(2011, c2.getGradYear());
		assertEquals(1066, c1.getGradYear());
		c2.setGradYear(777);
		assertEquals(1066, c1.getGradYear());
		assertEquals(777, c2.getGradYear());
	}
	
	@Test
	public void testFieldsAreDeclared() throws Exception {
		Map<Class<?>, Integer> required = new HashMap<>();
		required.put(String.class, 3);
		required.put(Integer.TYPE, 1);
		assertTrue(Util.verifyFields(Captain.class, required));
	}
	
	@Test
	public void testFieldsArePrivate() throws Exception {
		assertTrue(Util.allFieldsArePrivate(Captain.class));
	}
}
