package edu.ycp.cs201.exam1;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public class Util {
	/**
	 * Verify that required private fields are declared.
	 * 
	 * @param cls        class to check
	 * @param required   map of field types to required count (number of fields)
	 * @return true if the required fields are present, false otherwise
	 */
	public static boolean verifyFields(Class<?> cls, Map<Class<?>, Integer> required) {
		Map<Class<?>, Integer> found = new HashMap<>();
		
		// Count the number of instance fields of each type
		
		Field[] fields = cls.getDeclaredFields();
		
		for (Field f : fields) {
			if (f.isSynthetic() || (f.getModifiers() & Modifier.STATIC) != 0) {
				// ignore synthetic and static fields
				continue;
			}
			
			// found a private field, tally it
			Class<?> type = f.getType();
			if (type == Integer.class) { // Consider Integer to be int
				type = Integer.TYPE;
			}
			if (found.containsKey(type)) {
				found.put(type, found.get(type) + 1);
			} else {
				found.put(type, 1);
			}
		}
		
		for (Map.Entry<Class<?>, Integer> reqEntry : required.entrySet()) {
			Integer foundCount = found.get(reqEntry.getKey());
			if (foundCount == null || foundCount < reqEntry.getValue()) {
				// either no private fields of the required type were declared,
				// or not enough were declared
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Verify that there is at least one instance field, and that
	 * all instance fields are private.
	 * 
	 * @param cls  the class to check
	 * @return true if there is at least one instance field and all
	 *   fields are private
	 */
	public static boolean allFieldsArePrivate(Class<?> cls) {
		Field[] fields = cls.getDeclaredFields();
		int count = 0;
		for (Field f : fields) {
			if (!f.isSynthetic() && (f.getModifiers() & Modifier.PRIVATE) == 0) {
				return false;
			}
			if ((f.getModifiers() & Modifier.STATIC) == 0) {
				// found an instance field
				count++;
			}
		}
		return count > 0;
	}
}
