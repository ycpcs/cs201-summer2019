package edu.ycp.cs201.exam02;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Q11Test {
	private Pokemon eevee;
	private Pokemon pidgey;
	private Pokemon bulbasaur;
	private Pokemon pikachu;
	private Pokemon weedle;
	private Pokemon venonat;
	private Pokemon meowth;
	private Pokemon growlithe;
	private Pokemon paras;
	
	@Before
	public void setUp() {
		eevee = new Pokemon(PokemonType.NORMAL, "Eevee");
		pidgey = new Pokemon(PokemonType.NORMAL, PokemonType.FLYING, "Pidgey");
		bulbasaur = new Pokemon(PokemonType.GRASS, PokemonType.POISON, "Bulbasaur");
		pikachu = new Pokemon(PokemonType.ELECTRIC, "Pikachu");
		weedle = new Pokemon(PokemonType.BUG, PokemonType.POISON, "Weedle");
		venonat = new Pokemon(PokemonType.BUG, PokemonType.POISON, "Venonat");
		meowth = new Pokemon(PokemonType.NORMAL, "Meowth");
		growlithe = new Pokemon(PokemonType.FIRE, "Growlithe");
		paras = new Pokemon(PokemonType.BUG, PokemonType.GRASS, "Paras");
	}
	
	@Test
	public void testGetPrimaryTypeForSingleType() throws Exception {
		assertEquals(PokemonType.NORMAL, eevee.getPrimaryType());
		assertEquals(PokemonType.ELECTRIC, pikachu.getPrimaryType());
		assertEquals(PokemonType.NORMAL, meowth.getPrimaryType());
		assertEquals(PokemonType.FIRE, growlithe.getPrimaryType());
	}
	
	@Test
	public void testPrimaryTypeForDualType() throws Exception {
		assertEquals(PokemonType.NORMAL, pidgey.getPrimaryType());
		assertEquals(PokemonType.GRASS, bulbasaur.getPrimaryType());
		assertEquals(PokemonType.BUG, weedle.getPrimaryType());
		assertEquals(PokemonType.BUG, venonat.getPrimaryType());
		assertEquals(PokemonType.BUG, paras.getPrimaryType());
	}
	
	@Test
	public void testSecondaryTypeForSingleType() throws Exception {
		assertEquals(PokemonType.NONE, eevee.getSecondaryType());
		assertEquals(PokemonType.NONE, pikachu.getSecondaryType());
		assertEquals(PokemonType.NONE, meowth.getSecondaryType());
		assertEquals(PokemonType.NONE, growlithe.getSecondaryType());
	}
	
	@Test
	public void testSecondaryTypeForDualType() throws Exception {
		assertEquals(PokemonType.FLYING, pidgey.getSecondaryType());
		assertEquals(PokemonType.POISON, bulbasaur.getSecondaryType());
		assertEquals(PokemonType.POISON, weedle.getSecondaryType());
		assertEquals(PokemonType.POISON, venonat.getSecondaryType());
		assertEquals(PokemonType.GRASS, paras.getSecondaryType());
	}
	
	@Test
	public void testGetName() throws Exception {
		assertEquals("Eevee", eevee.getName());
		assertEquals("Pidgey", pidgey.getName());
		assertEquals("Bulbasaur", bulbasaur.getName());
		assertEquals("Pikachu", pikachu.getName());
		assertEquals("Weedle", weedle.getName());
		assertEquals("Venonat", venonat.getName());
		assertEquals("Meowth", meowth.getName());
		assertEquals("Growlithe", growlithe.getName());
		assertEquals("Paras", paras.getName());
	}
	
	@Test
	public void testCompareTo1() throws Exception {
		// normal vs. normal flying
		assertTrue(eevee.compareTo(pidgey) < 0);
		assertTrue(pidgey.compareTo(eevee) > 0);
	}
	
	@Test
	public void testCompareTo2() throws Exception {
		// normal vs. electric
		assertTrue(eevee.compareTo(pikachu) < 0);
		assertTrue(pikachu.compareTo(eevee) > 0);
	}
	
	@Test
	public void testCompareTo3() throws Exception {
		// grass poison vs. bug poison
		assertTrue(bulbasaur.compareTo(weedle) < 0);
		assertTrue(weedle.compareTo(bulbasaur) > 0);
	}
	
	@Test
	public void testCompareTo4() throws Exception {
		// bug poison vs. bug poison (names will decide the result)
		assertTrue(weedle.compareTo(venonat) > 0);
		assertTrue(venonat.compareTo(weedle) < 0);
	}
	
	@Test
	public void testCompareTo5() throws Exception {
		// bug poison vs. bug grass
		assertTrue(weedle.compareTo(paras) > 0);
		assertTrue(paras.compareTo(weedle) < 0);
	}
	
	@Test
	public void testCompareTo6() throws Exception {
		// normal vs. normal (names will decide the result)
		assertTrue(eevee.compareTo(meowth) < 0);
		assertTrue(meowth.compareTo(eevee) > 0);
	}
	
	@Test
	public void testCompareToSame() throws Exception {
		Pokemon pikachuCopy = new Pokemon(PokemonType.ELECTRIC, "Pikachu");
		Pokemon weedleCopy = new Pokemon(PokemonType.BUG, PokemonType.POISON, "Weedle");
		
		assertTrue(pikachuCopy.compareTo(pikachu) == 0);
		assertTrue(weedleCopy.compareTo(weedle) == 0);
	}
}
