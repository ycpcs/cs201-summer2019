package edu.ycp.cs201.exam02;

public class Pokemon implements Comparable<Pokemon> {
	// TODO: add fields and methods as required
	
	// SUPER IMPORTANT: look at the unit tests in Q11Test.
	// These will indicate exactly what methods are required
	// and how they should behave.  If there is a compilation
	// error in Q11Test, it means you are missing a
	// required method, or that a required method is not
	// defined correctly.  Make sure that this class defines
	// all of the methods needed by the test code.
	// DO NOT CHANGE ANY OF THE TEST CODE.
}
