package edu.ycp.cs201.fileio;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadCharacters {
	public static void main(String[] args) throws IOException {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Filename: ");
		String fileName = keyboard.nextLine();
		
		FileReader fr = new FileReader(fileName);
		int count = 0;
		
		while (true) {
			int c = fr.read();
			if (c < 0) {
				break;
			}
			if (c == 'e') {
				count++;
			}
		}
		
		fr.close(); // FIXME: this still isn't right!!!
		
		System.out.printf("%d occurrences of 'e'\n", count);
	}
}
