package edu.ycp.cs201.fileio;

import java.io.FileWriter;
import java.io.IOException;

public class WriteText {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("output.txt");
		fw.write("This is some text. Yay.\n");
		fw.close();
		
		System.out.println("Done");
	}
}
