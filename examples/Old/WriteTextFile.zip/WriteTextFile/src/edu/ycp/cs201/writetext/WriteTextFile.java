package edu.ycp.cs201.writetext;

import java.io.FileWriter;
import java.io.IOException;

public class WriteTextFile {
	public static void main(String[] args)
			throws IOException {
		FileWriter fout = new FileWriter("output.txt");
		fout.write("This is some file output\n");
		fout.write("A second line of text, woo");
		fout.close();
		
		System.out.println("Program is finished");
	}
}
