package edu.ycp.cs201.point;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.00001;
	
	// test fixture (objects to be tested)
	private Point origin;
	private Point p;
	private Point q;
	private Point r;
	
	// setup method (create the test fixture objects)
	@Before
	public void setUp() {
		origin = new Point();
		p = new Point(3.5, 4.6);
		q = new Point(-3.2, 0.9);
		r = new Point(3, 4);
	}
	
	// goal: test every public method
	
	// test methods
	@Test
	public void testGetX() throws Exception {
		assertEquals(0.0, origin.getX(), DELTA);
		assertEquals(3.5, p.getX(), DELTA);
		assertEquals(-3.2, q.getX(), DELTA);
	}
	
	@Test
	public void testDistanceFromOrigin() throws Exception {
		assertEquals(0.0, origin.distanceFromOrigin(), DELTA);
		assertEquals(5.0, r.distanceFromOrigin(), DELTA);
	}
}
