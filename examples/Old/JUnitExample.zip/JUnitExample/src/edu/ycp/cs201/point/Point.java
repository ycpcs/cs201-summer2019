package edu.ycp.cs201.point;

public class Point {
	private double x, y;
	
	public Point() {
		x = 0;
		y = 0;
	}
	
	public Point(double xval, double yval) {
		x = xval;
		y = yval;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public double distanceFromOrigin() {
		return Math.sqrt(x*x + y*y);
	}
}
