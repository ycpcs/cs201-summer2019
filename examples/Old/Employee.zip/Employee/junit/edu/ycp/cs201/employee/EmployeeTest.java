package edu.ycp.cs201.employee;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class EmployeeTest {
	// test fixture (objects being tested)
	private Employee emp;
	
	// setup method (create objects in test fixture)
	@Before
	public void setUp() {
		emp = new Employee("Homer Simpson", 30000);
	}
	
	// test methods (test objects in test fixture)
	@Test
	public void testGetName() {
		assertEquals("Homer Simpson", emp.getName());
	}
	
	@Test
	public void testSetName() {
		emp.setName("Lisa Simpson");
		assertEquals("Lisa Simpson", emp.getName());
	}
}
