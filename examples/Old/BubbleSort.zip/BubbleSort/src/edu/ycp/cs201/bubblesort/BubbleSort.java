package edu.ycp.cs201.bubblesort;

import java.util.Comparator;

public class BubbleSort {
	public static<E extends Comparable<E>> void bubbleSort(E[] arr) {
		int limit = arr.length;
		
		while (limit > 1) {
			for (int i = 1; i < limit; i++) {
				if (arr[i-1].compareTo(arr[i]) > 0) {
					E tmp = arr[i-1];
					arr[i-1] = arr[i];
					arr[i] = tmp;
				}
			}
			limit--;
		}
	}

	public static<E> void bubbleSort(E[] arr, Comparator<E> comp) {
		int limit = arr.length;
		
		while (limit > 1) {
			for (int i = 1; i < limit; i++) {
				if (comp.compare(arr[i-1], arr[i]) > 0) {
					E tmp = arr[i-1];
					arr[i-1] = arr[i];
					arr[i] = tmp;
				}
			}
			limit--;
		}
	}
	
	private static class Reverse implements Comparator<String> {
		@Override
		public int compare(String left, String right) {
			return right.compareTo(left);
		}
	}
	
	public static void main(String[] args) {
		String[] animals = new String[]{
				"dog", "armadillo", "pygmy marmoset", "axolotl", "aardvark"};
		//bubbleSort(animals, new Reverse());
		bubbleSort(animals, (a, b) -> b.compareTo(a));
		for (String a : animals) {
			System.out.println(a);
		}
	}
}
