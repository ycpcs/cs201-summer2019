package edu.ycp.cs201.examplegui;

public class CounterController {
	private Counter model;
	
	public CounterController() {
		
	}
	
	public void setModel(Counter model) {
		this.model = model;
	}
	
	public void increaseCount() {
		this.model.increment();
	}

	public void decreaseCount() {
		if (this.model.getCount() > 0) {
			this.model.decrement();
		}
	}
}
