package edu.ycp.cs201.countergui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class CounterView extends JPanel {
	private CounterModel model;
	private CounterController controller;
	
	public CounterView() {
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.GRAY);
		
		// add mouse event handler
		this.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
	}
	
	protected void handleMouseClick(MouseEvent e) {
		if (e.getButton() == 1) {
			controller.increment();
		}
		repaint();
	}

	public void setModel(CounterModel model) {
		this.model = model;
	}
	
	public void setController(CounterController controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g); // paint background
		
		Font f = new Font(Font.DIALOG, Font.BOLD, 44);
		g.setColor(Color.BLACK);
		g.setFont(f);
		g.drawString("" + model.getCount(), 10, 160);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				CounterModel model = new CounterModel();
				
				CounterController controller = new CounterController();
				controller.setModel(model);
				
				CounterView view = new CounterView();
				view.setModel(model);
				view.setController(controller);
				
				JFrame frame = new JFrame("Counter GUI");
				frame.setContentPane(view);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}
