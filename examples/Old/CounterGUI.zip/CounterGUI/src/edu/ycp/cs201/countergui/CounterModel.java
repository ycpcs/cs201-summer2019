package edu.ycp.cs201.countergui;

public class CounterModel {
	private int count;
	
	public CounterModel() {
		this.count = 0;
	}
	
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
}
