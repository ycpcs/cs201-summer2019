package edu.ycp.cs201.countergui;

public class CounterController {
	private CounterModel model;
	
	public CounterController() {
		
	}
	
	public void setModel(CounterModel model) {
		this.model = model;
	}
	
	public void increment() {
		int current = model.getCount();
		current = current + 1;
		model.setCount(current);
	}
}
