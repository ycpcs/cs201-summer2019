package edu.ycp.cs201.readchars;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadCharacters {
	public static void main(String[] args)
			throws IOException {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter a filename: ");
		String fileName = keyboard.nextLine();
		
		FileReader fin = new FileReader(fileName);
		int count = 0;
		while (true) {
			int c = fin.read();
			if (c < 0) {
				break;
			}
			c = Character.toLowerCase(c);
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o'
					|| c== 'u') {
				count++;
			}
		}
		fin.close();
		
		System.out.println("Saw " + count + " vowels");
	}
}
