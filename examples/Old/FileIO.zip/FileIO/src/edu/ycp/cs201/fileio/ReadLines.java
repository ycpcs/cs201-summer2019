package edu.ycp.cs201.fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadLines {
	public static void main(String[] args) throws IOException {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		String fileName;
		System.out.print("Enter a filename: ");
		fileName = keyboard.nextLine();
		
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);

		int longest = 0;
		while (true) {
			String line = br.readLine();
			if (line == null) {
				break;
			}
			if (line.length() > longest) {
				longest = line.length();
			}
		}
		
		br.close();
		
		System.out.printf("Longest line was %d characters\n", longest);
	}
}
