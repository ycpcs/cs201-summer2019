package edu.ycp.cs201.fileio;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("output.txt");
		fw.write("Hi there!\n");
		fw.close();
		
		System.out.println("Wrote to the file!");
	}
}
