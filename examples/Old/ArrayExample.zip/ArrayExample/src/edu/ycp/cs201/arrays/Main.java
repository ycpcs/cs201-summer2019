package edu.ycp.cs201.arrays;

public class Main {
	public static void main(String[] arg) {
		int[] a = new int[4];
		a[0] = 42;
		a[1] = 17;
		
		printIntArray(a);
	}
	
	public static void printIntArray(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.printf("%d\n", arr[i]);
		}
	}
}
