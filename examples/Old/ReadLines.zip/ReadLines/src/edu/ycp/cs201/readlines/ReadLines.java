package edu.ycp.cs201.readlines;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadLines {
	public static void main(String[] args)
			throws IOException {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter a filename: ");
		String fileName = keyboard.nextLine();
		
		FileReader fin = new FileReader(fileName);
		BufferedReader bin = new BufferedReader(fin);
		int max = 0;
		
		while (true) {
			String line = bin.readLine();
			if (line == null) {
				break;
			}
			if (line.length() > max) {
				max = line.length();
			}
		}
		bin.close();
		
		System.out.printf(
				"Longest line has %d chars\n", max);
	}
}
