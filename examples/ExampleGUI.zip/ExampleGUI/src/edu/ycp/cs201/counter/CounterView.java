package edu.ycp.cs201.counter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class CounterView extends JPanel {
	private static final long serialVersionUID = 1L;

	private CounterModel model;
	private CounterController controller;
	
	public CounterView() {
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.GRAY);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClicked(e);
			}
		});
	}
	
	protected void handleMouseClicked(MouseEvent e) {
		if (e.getButton() == 1) { //left
			controller.increment();
		} else if (e.getButton() == 3) { //right
			controller.decrement();
		}
		repaint();
	}


	public void setModel(CounterModel model) {
		this.model = model;
	}
	
	public void setController(CounterController controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// Paint background color
		super.paintComponent(g);
		
		Font f = new Font("Dialog", Font.BOLD, 96);
		g.setFont(f);
		g.setColor(Color.GREEN);
		g.drawString("" + model.getCount(), 20, 160);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				CounterModel model = new CounterModel();
				CounterController controller = new CounterController();
				controller.setModel(model);
				CounterView view = new CounterView();
				view.setController(controller);
				view.setModel(model);
				
				JFrame frame = new JFrame("Counter");
				frame.setContentPane(view);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.pack();
				frame.setVisible(true);
			}
		});
	}
}
