package edu.ycp.cs201.counter;

public class CounterController {
	private final int MAX = 100000;
	
	private CounterModel model;

	public void setModel(CounterModel model) {
		this.model = model;
	}

	public void increment() {
		int currentCount = model.getCount();
		if (currentCount < MAX) {
			model.setCount(currentCount + 1);
		}
	}

	public void decrement() {
		int currentCount = model.getCount();
		if (currentCount > 0) {
			model.setCount(currentCount - 1);
		}
	}

}
