package edu.ycp.cs201.point;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.000001;
	
	// test fixture
	private Point origin;
	private Point testPoint;
	
	// setup method
	@Before
	public void setUp() {
		origin = new Point(0.0, 0.0);
		testPoint = new Point(3.0, 4.0);
	}
	
	// test methods
	@Test
	public void testGetX() {
		assertEquals(0.0, origin.getX(), DELTA);
		assertEquals(3.0, testPoint.getX(), DELTA);
	}
	
	@Test
	public void testGetY() {
		assertEquals(0.0, origin.getY(), DELTA);
		assertEquals(4.0, testPoint.getY(), DELTA);
	}
	
	@Test
	public void testDistanceTo() {
		assertEquals(5.0, origin.distanceTo(testPoint), DELTA);
		assertEquals(5.0, testPoint.distanceTo(origin), DELTA);
	}
}
