package edu.ycp.cs201.point;

public class Point {
	private double x;
	private double y;
	
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public double getX() {
		return this.x;
	}
	
	public double getY() {
		return this.y;
	}
	
	public double distanceTo(Point other) {
		double xdiff = this.x - other.x;
		double ydiff = this.y - other.y;
		return Math.sqrt(xdiff*xdiff + ydiff*ydiff);
	}
}
