package edu.ycp.cs201.change;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Change {
	static class Coins {
		private List<Integer> coins;
		public Coins() {
			coins = new ArrayList<>();
		}
		public void add(int coin) {
			coins.add(coin);
		}
		public void add(Coins other) {
			if (other == null) { throw new IllegalArgumentException(); }
			coins.addAll(other.coins);
		}
		public int numCoins() {
			return coins.size();
		}
		@Override
		public String toString() {
			return coins.toString();
		}
	}
	
	private static final int[] DENOM = { 1, 5, 10, 21, 25 };
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Make change for what amount: ");
		int amount = keyboard.nextInt();
		
		Coins[] memo = new Coins[amount+1];
		for (int coin : DENOM) {
			memo[coin] = new Coins();
			memo[coin].add(coin);
		}
		
		for (int i = 1; i <= amount; i++) {
			if (memo[i] == null) {
				Coins best = null;
				
				for (int coin : DENOM) {
					int remaining = i - coin;
					if (remaining > 0) {
						Coins prev = memo[remaining];
						if (prev == null) {
							System.out.println("No optimal change for " + remaining + "?");
						}
						Coins candidate = new Coins();
						candidate.add(prev);
						candidate.add(coin);
						if (best == null || candidate.numCoins() < best.numCoins()) {
							best = candidate;
						}
					}
				}
				if (best == null) {
					throw new IllegalStateException("No solution for " + i);
				}
				
				memo[i] = best;
			}
		}
		
		System.out.println("Optimal change is: " + memo[amount].toString());
	}
}
